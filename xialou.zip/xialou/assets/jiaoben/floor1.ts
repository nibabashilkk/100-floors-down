import { _decorator, Component, Node, Collider2D, Contact2DType, IPhysics2DContact, Animation, Vec3 } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('floor1')
export class floor1 extends Component {
    start() {
		let collider = this.getComponent(Collider2D);
		if (collider) {
			collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
		}
    }
	onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
		// 只在两个碰撞体开始接触时被调用一次
		if(otherCollider.node.name = "ball"){
			this.getComponent(Animation).play();
			setTimeout(()=>{
				if(this.node){
				this.node.active = false;
				}
			},3000)
		}
	}

    update(deltaTime: number) {
		let self = this;
		let n = this.node.parent.getComponent(main).n;
		this.node.position = new Vec3(this.node.position.x, this.node.position.y + 1 + n, 0);
		if (this.node.position.y >= 1000) {
			setTimeout(() => {
				self.node.destroy();
			}, 0);
		}
    }
}


