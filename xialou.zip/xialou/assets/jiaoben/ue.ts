import { _decorator, Component, Node, Collider2D, Contact2DType, IPhysics2DContact } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('ue')
export class ue extends Component {
    start() {
		let collider = this.getComponent(Collider2D);
		if (collider) {
			collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
		}
    }
	onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
		if(otherCollider.node.name == "ball"){
			this.node.parent.getComponent(main).stopgame();
		}
	}

    update(deltaTime: number) {
        
    }
}


