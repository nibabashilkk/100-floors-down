import { _decorator, Component, Node, Button, director } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('home')
export class home extends Component {
	start() {
		let button = this.node.getComponent(Button);
		button.node.on(Button.EventType.CLICK, this.home, this);
	}
	home(button: Button) {
		director.loadScene("start");
		this.node.parent.destroy();
	}

    update(deltaTime: number) {
        
    }
}


