import { _decorator, Component, Node, Vec3, Collider2D, Contact2DType, PhysicsSystem2D, Label } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('muban')
export class muban extends Component {
    start() {
	}
	
    update(deltaTime: number) {
		let self = this;
		let n = this.node.parent.getComponent(main).n;
        this.node.position = new Vec3(this.node.position.x,this.node.position.y+1+n,0);
		if (this.node.position.y>=1000){
			setTimeout(()=>{
				self.node.destroy();
			},0);
		}
    }
}


