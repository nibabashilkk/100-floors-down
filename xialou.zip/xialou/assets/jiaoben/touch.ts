import { _decorator, Component, Node, AudioSource, Collider2D, Contact2DType, IPhysics2DContact } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('touch')
export class touch extends Component {
	touch: AudioSource = null;
    start() {
		this.touch = this.getComponent(AudioSource);
		let collider = this.getComponent(Collider2D);
		if (collider) {
			collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
		}
    }
	onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
		this.touch.play();
	}

    update(deltaTime: number) {
        
    }
}


