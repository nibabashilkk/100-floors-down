import { _decorator, Component, Node, Vec3, Label, tween } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('bggd')
export class bggd extends Component {
	back1: Node = null;
	back2: Node = null;
	onLoad(){
		this.back1 = this.node.getChildByName("back1");
		this.back2 = this.node.getChildByName("back2");
	}
    start() {
		

    }
    update(deltaTime: number) {
		let n = this.node.parent.getComponent(main).n;
		this.back1.setPosition(0,this.back1.position.y+1+n,0);
		this.back2.setPosition(0,this.back2.position.y+1+n,0);
		console.log(this.back1.position);
		if (this.back1.position.y>=3000){
			this.back1.position = new Vec3(0,-3000,0);
		}
		if(this.back2.position.y>=3000){
			this.back2.position = new Vec3(0,-3000,0);
		}
		
    }
}


