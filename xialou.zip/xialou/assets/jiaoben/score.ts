import { _decorator, Component, Node,Label} from 'cc';
const { ccclass, property } = _decorator;

@ccclass('score')
export class score extends Component {
	score :number = 0;
    start() {

    }

    update(deltaTime: number) {
		this.score+=3;
		let x = this.score/3000;
        this.getComponent(Label).string = Math.floor(x).toString();
    }
}


