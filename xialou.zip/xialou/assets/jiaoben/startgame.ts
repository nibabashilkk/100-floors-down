import { _decorator, Component, Node, Button, director } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('startgame')
export class startgame extends Component {
    start() {
		let button = this.node.getComponent(Button);
		button.node.on(Button.EventType.CLICK,this.startgame,this);
    }
	startgame(button:Button){
		director.loadScene("game");
		if (director.isPaused) {
			director.resume();
		}
	}

    update(deltaTime: number) {
        
    }
}


