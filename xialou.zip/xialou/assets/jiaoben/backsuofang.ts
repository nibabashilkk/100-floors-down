import { _decorator, Component, Node, view, Vec3 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('backsuofang')
export class backsuofang extends Component {
    start() {
		
    }
	onLoad(){
		let fblwith = view.getDesignResolutionSize().width;
		let fblheight = view.getDesignResolutionSize().height;
		let scaleforshowall = Math.min(
			960 / fblwith,
			640 / fblheight
		);
		let realwith = fblwith * scaleforshowall;
		let realheight = fblheight * scaleforshowall;
		this.node.scale = new Vec3(Math.max(
			960 / realwith,
			640 / realheight
		),2.5);
	}
    update(deltaTime: number) {
        
    }
}


