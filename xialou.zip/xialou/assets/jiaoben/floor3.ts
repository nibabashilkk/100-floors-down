import { _decorator, Component, Node, Collider2D, Contact2DType, IPhysics2DContact, Vec3 } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('floor3')
export class floor3 extends Component {
    start() {
		let collider = this.getComponent(Collider2D);
		if (collider) {
			collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
		}
    }
	onBeginContact(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
		// 只在两个碰撞体开始接触时被调用一次
		if(otherCollider.node.name == "ball"){
			this.node.parent.getComponent(main).stopgame();
		}
	}

    update(deltaTime: number) {
		let self = this;
		let n = this.node.parent.getComponent(main).n;
		this.node.position = new Vec3(this.node.position.x, this.node.position.y + 1 + n, 0);
		if (this.node.position.y >= 1000) {
			setTimeout(() => {
				self.node.destroy();
			}, 0);
		}
    }
}


