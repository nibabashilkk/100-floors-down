import { _decorator, Component, Node, Prefab, instantiate, Vec3, randomRange, EventTouch, UITransform, RigidBody, RigidBody2D, Vec2, physics, PhysicsSystem2D, v2, PHYSICS_2D_PTM_RATIO, Game, game, director } from 'cc';
import { heart } from './heart';
const { ccclass, property } = _decorator;

@ccclass('main')
export class main extends Component {
	@property([Prefab])
	floors:Prefab[] = [];
	ball:Node = null;
	n : number = 0;
	length:number = 300;
    start() {
		this.ball = this.node.getChildByName("ball");
		this.schedule(() => {
			this.n+=0.1;
		}, 5)
		this.node.on(Node.EventType.TOUCH_START,this.movestart,this)
		this.node.on(Node.EventType.TOUCH_END,this.moveend,this)
		PhysicsSystem2D.instance.gravity = v2(0, -20*PHYSICS_2D_PTM_RATIO);
    }
	update(deltaTime: number) {
		this.length-=this.n+1;
		if(this.length<=0){
			this.generalfloor();
			this.length = 300;
		}
		if (this.ball.position.y <= -1000) {
		this.stopgame();
		}
	}
	movestart(touch:EventTouch){
		let position = touch.getUILocation();
		let x = this.node.getComponent(UITransform).convertToNodeSpaceAR(new Vec3(position.x,position.y,0)).x;
		if(x>0){
			this.ball.getComponent(RigidBody2D).linearVelocity = new Vec2(20, this.ball.getComponent(RigidBody2D).linearVelocity.y);
		}else{
			this.ball.getComponent(RigidBody2D).linearVelocity = new Vec2(-20, this.ball.getComponent(RigidBody2D).linearVelocity.y);
		}
	}
	moveend(touch:EventTouch){
		this.ball.getComponent(RigidBody2D).linearVelocity = new Vec2(0, this.ball.getComponent(RigidBody2D).linearVelocity.y);
	}
	generalfloor(){
		let floor = instantiate(this.floors[Math.floor(Math.random()*(this.floors.length-1))]);
		floor.parent = this.node;
		floor.position = new Vec3(randomRange(-380,380),-1000,0);
	}
	stopgame(){
			let alert = instantiate(this.floors[6]);
			alert.setPosition(new Vec3(0,0,0));
			alert.parent = this.node;
			director.pause();
	}
}


