import { _decorator, Component, Node, RigidBody2D, Collider2D, Contact2DType, Vec2, IPhysics2DContact, Vec3, Label } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('floor4_1')
export class floor4_1 extends Component {
    start() {
		let collider = this.getComponent(Collider2D);
		if (collider) {
			collider.on(Contact2DType.POST_SOLVE, this.onPreSolve, this);
			
		}
	}
	onPreSolve(selfCollider: Collider2D, otherCollider: Collider2D, contact: IPhysics2DContact | null) {
		let x = otherCollider.getComponent(RigidBody2D).linearVelocity.x;
		otherCollider.getComponent(RigidBody2D).linearVelocity = new Vec2(x+0.2,0);
	}
    update(deltaTime: number) {
		let self = this;
		let n = this.node.parent.getComponent(main).n;
		this.node.position = new Vec3(this.node.position.x, this.node.position.y + 1+n, 0);
		if (this.node.position.y >= 1000) {
			setTimeout(() => {
				self.node.destroy();
			}, 0);
		}
    }
}


