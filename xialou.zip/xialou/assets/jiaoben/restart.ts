import { _decorator, Component, Node, Button, director, Vec3, RigidBody2D, Vec2 } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('restart')
export class restart extends Component {
	restart:Button = null;
    start() {
		this.restart = this.getComponent(Button);
		this.restart.node.on(Button.EventType.CLICK,this.click,this);
    }
	click(button:Button){
		director.resume();
		let ball = this.node.parent.parent.getChildByName("ball");
		ball.setPosition(new Vec3(0,300,0));
		ball.getComponent(RigidBody2D).linearVelocity = new Vec2(0,0);
		this.node.parent.destroy();
	}

    update(deltaTime: number) {
        
    }
}


