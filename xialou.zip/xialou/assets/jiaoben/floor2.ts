import { _decorator, Component, Node, Collider2D, physics, Physics2DManifoldType, Contact2DType, animation, AnimationClip, Animation, RigidBody2D, Vec3, Vec2, Label } from 'cc';
import { main } from './main';
const { ccclass, property } = _decorator;

@ccclass('floor2')
export class floor2 extends Component {
	donghua: Animation = null;
	ball: Node = null;
    start() {
		this.ball = this.node.parent.getChildByName("ball");
		this.donghua = this.getComponent(Animation);
		let collider = this.getComponent(Collider2D);
		if (collider) {
			collider.on(Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
		}
    }
	onBeginContact(){
		this.donghua.play();
		this.ball.getComponent(RigidBody2D).linearVelocity = new Vec2(this.ball.getComponent(RigidBody2D).linearVelocity.x,20);
	}


    update(deltaTime: number) {
		let self = this;
		let n = this.node.parent.getComponent(main).n;
		this.node.position = new Vec3(this.node.position.x, this.node.position.y + 1+n, 0);
		if (this.node.position.y >= 1000) {
			setTimeout(() => {
				self.node.destroy();
			}, 0);
		}
    }
}


